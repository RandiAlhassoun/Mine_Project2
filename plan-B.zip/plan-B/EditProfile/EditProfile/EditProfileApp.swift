
import SwiftUI

@main
struct EditProfileApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
