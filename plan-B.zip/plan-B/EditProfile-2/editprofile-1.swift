//
//  editprofile-1.swift
//  EditProfile
//
//  Created by WadiahAlbuhairi on 19/05/1444 AH.
//

import SwiftUI

struct editprofile_1: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

struct editprofile_1_Previews: PreviewProvider {
    static var previews: some View {
        editprofile_1()
    }
}
